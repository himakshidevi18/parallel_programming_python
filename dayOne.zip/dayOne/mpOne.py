import multiprocessing as mp 

print(f'Total number of processors: {mp.cpu_count()}')
