'''
    Importing some of the symbols(functions/classes/data) directly

'''
from moduleIntro import funOne, dataOne
import moduleIntro

funOne()
print(dataOne)


moduleIntro.funTwo()
print(moduleIntro.dataTwo)
