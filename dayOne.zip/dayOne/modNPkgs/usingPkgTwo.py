import myPkg.moduleIntro as mp

mp.funOne()
mp.funTwo()
print(mp.dataOne)
print(mp.dataTwo)
