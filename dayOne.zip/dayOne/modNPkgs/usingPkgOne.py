import myPkg.moduleIntro

myPkg.moduleIntro.funOne()
myPkg.moduleIntro.funTwo()
print(myPkg.moduleIntro.dataOne)
print(myPkg.moduleIntro.dataTwo)
