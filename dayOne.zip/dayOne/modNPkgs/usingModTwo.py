'''
    Importing all symbols(functions/classes/data) directly

'''
from moduleIntro import *

funOne()
funTwo()
print(dataOne)
print(dataTwo)
