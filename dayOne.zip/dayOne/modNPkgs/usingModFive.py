'''
    Importing some of the symbols(functions/classes/data) directly

'''
from moduleIntro import funOne, dataOne
import moduleIntro as mi

funOne()
print(dataOne)


mi.funTwo()
print(mi.dataTwo)
