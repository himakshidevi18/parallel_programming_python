'''
    Importing some of the symbols(functions/classes/data) directly

'''
from moduleIntro import funOne, dataOne

funOne()
print(dataOne)
