
import moduleIntro


moduleIntro.funOne()
moduleIntro.funTwo()
print(moduleIntro.dataOne)
print(moduleIntro.dataTwo)

