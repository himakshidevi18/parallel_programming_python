'''
'''

def fun():
    print('fun',__name__)


fun()
