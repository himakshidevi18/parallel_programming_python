#!/usr/bin/python3
from time import sleep
while True:
    print('Hello')
    sleep(.3)
