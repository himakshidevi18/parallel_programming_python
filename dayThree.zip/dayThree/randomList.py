from random import randint

var = randint(1,100)

lst = [randint(1,100) for i in range(50)]
print(var)
print(lst)

