#!/usr/bin/python3

for i in range(10):
    print('X', end='')
