#!/usr/bin/python3
from multiprocessing import cpu_count

print(f'Total Processors: {cpu_count()}')
